@echo off
setlocal
title Takem Titans 2.0.0 Installer
set "MC=%APPDATA%\.minecraft"
set "NF=21.1.256"
set "HERE=%~dp0"
echo.
echo  === Takem Titans 2.0.0 ===
echo  Installs NeoForge %NF% for Minecraft 1.21.1 and the mod.
echo  Close the Minecraft Launcher before continuing.
echo.
pause
if not exist "%MC%" (
  echo Minecraft folder not found. Start the official launcher once, then run this again.
  pause & exit /b 1
)
set "JAVA="
where java >nul 2>nul && set "JAVA=java"
if not defined JAVA for /r "%LOCALAPPDATA%\Packages" %%J in (javaw.exe) do if not defined JAVA set "JAVA=%%J"
if not defined JAVA for /r "%ProgramFiles(x86)%\Minecraft Launcher\runtime" %%J in (javaw.exe) do if not defined JAVA set "JAVA=%%J"
if not defined JAVA for /r "%MC%\runtime" %%J in (javaw.exe) do if not defined JAVA set "JAVA=%%J"
if not defined JAVA (
  echo Java was not found. Install Java 21 from https://adoptium.net and run this again.
  pause & exit /b 1
)
echo Downloading NeoForge %NF% ...
curl -L -o "%TEMP%\neoforge-installer.jar" "https://maven.neoforged.net/releases/net/neoforged/neoforge/%NF%/neoforge-%NF%-installer.jar" || (echo Download failed. & pause & exit /b 1)
echo Installing NeoForge ...
"%JAVA%" -jar "%TEMP%\neoforge-installer.jar" --install-client "%MC%" || (echo NeoForge install failed. & pause & exit /b 1)
if not exist "%MC%\mods" mkdir "%MC%\mods"
del /q "%MC%\mods\takemtitans-*.jar" 2>nul
copy /y "%HERE%takemtitans-2.0.0.jar" "%MC%\mods\" >nul || (echo Could not copy the mod. & pause & exit /b 1)
echo.
echo Done! Open the Minecraft Launcher, pick the "neoforge-%NF%" profile and press Play.
echo Tip: give it at least 4 GB of RAM in the profile's JVM arguments (-Xmx4G).
pause
